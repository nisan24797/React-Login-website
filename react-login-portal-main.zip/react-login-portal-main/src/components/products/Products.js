import React from "react";

export default function Products() {
  return <h1>Product List</h1>;
}
